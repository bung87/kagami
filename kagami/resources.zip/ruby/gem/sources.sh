#!/usr/bin/env bash
gem sources --remove https://rubygems.org/
gem sources -a https://ruby.taobao.org/